package dataAccessObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

import geometry.WeightedGraph;
import geometry.*;
/**
 * 
 * @author Omar Totangy and Elias Rönnlund
 * <h1>DataDAO class</h1>
 * This class reads in file and works the file into usable format.
 */
public class DataDAO {	
	private String filePath;
	private WeightedGraph wg;
	public DataDAO() throws FileNotFoundException, IOException {
		openFileDialog();
	}
	/**
	 * Opens file dialog.
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	private void openFileDialog() throws FileNotFoundException, IOException {
		JFileChooser jfc = new JFileChooser();
		JButton jb = new JButton();
		jfc.setCurrentDirectory(new File("/Users/omartotangy/Downloads/aod-git_lab1/points_640000.txt"));
		FileNameExtensionFilter filter = new FileNameExtensionFilter("TEXT FILES", "txt","text");
		jfc.setFileFilter(filter);
		jfc.setDialogTitle("Open File");
		
		if(jfc.showOpenDialog(jb) == JFileChooser.APPROVE_OPTION) {
			//
		}
		filePath = jfc.getSelectedFile().getAbsolutePath();
		System.out.println(filePath);
		workTheData(loadList(filePath, 10));
		
	}
	/**
	 * Loads the list to a double matrix. 
	 * @param path String 
	 * @param size int 
	 * @return double[][]
	 * @throws IOException Wrong file
	 * @throws FileNotFoundException No file
	 */
	public double[][] loadList(String path, int size) throws IOException, FileNotFoundException{
		int s = 0;
		ArrayList<Double[]> list = new ArrayList<Double[]>();
		BufferedReader in = new BufferedReader(new FileReader(path));
		String l;
		String[] elementBuffer;
		Double[] valueBuffer;
		while((l = in.readLine()) != null && s<size) {
			
			elementBuffer = l.trim().split(" ");
			valueBuffer = new Double[2];
			valueBuffer[0] = Double.parseDouble(elementBuffer[0]);
			valueBuffer[1] = Double.parseDouble(elementBuffer[1]);
			//System.out.println("X: " + valueBuffer[0] + " Y: " + valueBuffer[1]);
			list.add(valueBuffer);
			s++;
		}
		in.close();
		
		double[][] returnList = new double[list.size()][2];
		Double[] data;
		
		for(int i = 0; i<list.size(); i++) {
			data = list.get(i);
			returnList[i][0] = data[0];
			returnList[i][1] = data[1];
		}
		
		
		return returnList;
	}
	/**
	 * Changes the double matrix into points in the WeightedGraph.
	 * @param points double[][]
	 */
	private void workTheData(double[][] points) {
		ArrayList<Node> pointList = new ArrayList<Node>();
		Node p;
		wg = new WeightedGraph();
		for(int i = 0; i<points.length; i++) {
			p = new Node();
			pointList.add(p);
			p.setX(points[i][0]);
			p.setY(points[i][1]);
			wg.addNode(p, "" + i);
		}
	}
	/**
	 * Returns the created graph. 
	 * @return WeightedGraph
	 */
	public WeightedGraph getGraph() {
		return wg;
	}
	
}
