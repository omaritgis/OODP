package graphGUI;

import java.awt.Color;
import java.util.ArrayList;

import geometry.Edge;
import geometry.Node;
import geometry.WeightedGraph;
import se.hig.aod_git.gui.ObjectRenderer;
import se.hig.aod_git.gui.ViewerWindow;
import se.hig.aod_git.types.geomtypes.LineSegment2D;
import se.hig.aod_git.types.geomtypes.Point2D;
import se.hig.aod_git.types.geomtypes.Vertex2D;
/**
 * 
 * @author Omar Totangy and Elias Rönnlund
 * <h1>GUI class</h1>
 * This class shows the graph window. 
 */
public class GUI {
	
	private Point2D nodePrev1 = null;
	private Point2D nodePrev2 = null;
	LineSegment2D markedLinePrev = null;
	//private int valueInc = 0;
	private ViewerWindow window;
	private ObjectRenderer renderer;
	private final Color STANDARD_GRAPH_COLOR = new Color(0, 0, 0);
	private final Color MARKED = new Color(0, 0, 255);
	private int windowScale = 45;
	private double xDiff = 0;
	double yDiff = 0;
	/**
	 * Creates the window.
	 */
	public GUI() {
		renderer = new ObjectRenderer();
		window = new ViewerWindow(renderer, "Map Of Things");
	}
	/**
	 * Draws the graph to the window. 
	 * @param graph WeightedGraph
	 * @param color Color
	 * @param remove boolean
	 */
	public void drawGraph(WeightedGraph graph, Color color, boolean remove) {
		
		ArrayList<Node> w = graph.getNodeList();
		ArrayList<Edge> edges = graph.getEdgeList();
		
		if (remove) {
			renderer = new ObjectRenderer();
			int centralValueIndex = getCentralValueIndex(w);
			xDiff = getXDiff(w.get(centralValueIndex));
			yDiff = getYDiff(w.get(centralValueIndex));
		}
		
		renderer.setColor(color);
		renderer.setScaleFactor(windowScale, windowScale);
		
		
		for(int i = 0; i<w.size(); i++) {
			renderer.addObject(new Point2D(new Vertex2D(w.get(i).getX() + xDiff,w.get(i).getY() + yDiff)));
			//System.out.println("X: " + w.get(i).getX() + " Y: " + w.get(i).getY());
			//System.out.println("X: " + (w.get(i).getX() + xDiff) + " Y: " + (w.get(i).getY() + yDiff));
		}
		
		for (Edge e : edges) {
			double x1 = e.getStartNode().getX() + xDiff;
			double y1 = e.getStartNode().getY() + yDiff;
			double x2 = e.getEndNode().getX() + xDiff;
			double y2 = e.getEndNode().getY() + yDiff;
			Vertex2D start = new Vertex2D(x1, y1);
			Vertex2D end = new Vertex2D(x2, y2);
			renderer.addObject(new LineSegment2D(start, end));
		}
		window.dispose();
		window = new ViewerWindow(renderer, "Map of Things");
	}
	/**
	 * Gets X diff
	 * @param node Node
	 * @return double
	 */
	private double getXDiff(Node node) {
		double xDiff = 0;
		double x = node.getX();
		if (node.getX() < 0) {
			while (x < 0) {
				x += 0.1;
				xDiff += 0.1;
			}
		}
		else if (node.getX() > 0) {
			while (x > 0) {
				x -= 0.1;
				xDiff -= 0.1;
			}
		}
		return xDiff;
	}
	/**
	 * Gets the Y diff
	 * @param node Node
	 * @return double
	 */
	private double getYDiff(Node node) {
		double yDiff = 0;
		double y = node.getY();
		if (node.getY() < 0) {
			while (y < 0) {
				y += 0.1;
				y += 0.1;
			}
		}
		else if (node.getY() > 0) {
			while (y > 0) {
				y -= 0.1;
				yDiff -= 0.1;
			}
		}
		return yDiff;
	}
	/**
	 * Gets the central value index.
	 * @param nodes ArrayList<Node>
	 * @return int
	 */
	private int getCentralValueIndex(ArrayList<Node> nodes){
		
		ArrayList<Double> summedNodes = new ArrayList<Double>();
		double nodeSum = 0;
		for (Node n : nodes) {
			summedNodes.add(n.getX() + n.getY());
			nodeSum = nodeSum + n.getX() + n.getY();
		}
		
		double nodeSumAverage = nodeSum / nodes.size();
		
		double nodeAbs;
		double centralValue = Double.POSITIVE_INFINITY;
		int centralValueIndex = 0;
		int i = 0;
		for (Double sN : summedNodes) {
			nodeAbs = Math.abs(nodeSumAverage - sN);
			if (nodeAbs < centralValue) {
				centralValue = nodeAbs;
				centralValueIndex = i;
			}
			i++;
		}
		
		return centralValueIndex;
		
	}
	/**
	 * Zooms the window
	 * @param scaleValue int
	 */
	public void zoom(int scaleValue) {
		windowScale = windowScale + scaleValue;
		renderer.setScaleFactor(windowScale, windowScale);
		window.dispose();
		window = new ViewerWindow(renderer, "Map Of Things");
	}
	/**
	 * Marks the point selected.
	 * @param nodeNbr int
	 * @param node Node
	 */
	public void markPoint (int nodeNbr, Node node) {
		
		if (nodePrev1 == null || nodePrev2 == null) {
			xDiff = getXDiff(node);
			yDiff = getYDiff(node);
		}
		
		renderer.setColor(STANDARD_GRAPH_COLOR);
		if (nodeNbr == 1 && nodePrev1 != null) {
			renderer.addObject(nodePrev1);
		}
		
		else if (nodeNbr == 2 && nodePrev2 != null) {
			renderer.addObject(nodePrev2);
		}
		
		renderer.setColor(MARKED);
		Point2D markedPoint = new Point2D(new Vertex2D(node.getX() + xDiff, node.getY() + yDiff));

		if (nodeNbr == 1) {
			nodePrev1 = markedPoint;
		}
		else {
			nodePrev2 = markedPoint;
		}
		renderer.addObject(markedPoint);
		window.dispose();
		window = new ViewerWindow(renderer, "Map of Things");
		
	}
	/**
	 * Marks the selected edge. 
	 * @param startNode Node
	 * @param endNode Node
	 */
	public void markLine(Node startNode, Node endNode) {
		
		if (markedLinePrev != null) {
			renderer.setColor(STANDARD_GRAPH_COLOR);
			renderer.addObject(markedLinePrev);
		}
		
		renderer.setColor(MARKED);
		LineSegment2D markedLine = new LineSegment2D(new Vertex2D(startNode.getX() + xDiff, startNode.getY() + yDiff), new Vertex2D (endNode.getX() + xDiff, endNode.getY() + yDiff));
		markedLinePrev = markedLine;
		renderer.addObject(markedLine);
		
		window.dispose();
		window = new ViewerWindow(renderer, "Map of Things");
	}

}
