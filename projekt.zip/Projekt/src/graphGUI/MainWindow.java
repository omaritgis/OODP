package graphGUI;

import geometry.*;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import dataAccessObject.DataDAO;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.border.LineBorder;
import java.awt.Color;

/**
 * 
 * @author Omar Totangy and Elias Rönnlund
 * 
 *         <h1>MainWindow class</h1> This class is the main class that triggers
 *         all that happens.
 *         
 *        
 */
public class MainWindow {

	private JFrame frame;
	private JTextField weightTxtFld;
	private JTextField infoBox;
	private JPanel graphPanel, panel;
	private WeightedGraph mainGraph;
	private WeightedGraph currentGraph;
	private GUI ui;
	private final int ZOOM_VALUE = 10;
	private final Color STANDARD_GRAPH_COLOR = new Color(0, 0, 0);
	private final Color LEAST_COST_COLOR = new Color(255, 0, 255);
	private final Color LEAST_COSTALL_COLOR = new Color(255, 255, 0);
	private final Color SHORTEST_DISTANCE_COLOR = new Color(0, 255, 255);
	private JButton btnLeastCostPath, btnLeastCostPathAll, btnSampleEdges, btnShortestPath, btnClearInfobox,
			btnAddWeight, btnZoomIn, btnZoomOut, readDataBtn;
	private JComboBox<String> nodeOne, nodeTwo, edgeOne;
	private JButton btnAddLine;

	/**
	 * Launch the application.
	 * @param args arguments
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainWindow window = new MainWindow();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainWindow() {
		initialize();
		ui = new GUI();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1050, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		graphPanel = new JPanel();
		graphPanel.setBackground(Color.WHITE);
		graphPanel.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		graphPanel.setBounds(20, 20, 746, 502);
		frame.getContentPane().add(graphPanel);
		graphPanel.setLayout(null);

		panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setBackground(Color.WHITE);
		panel.setBounds(370, 6, 370, 116);
		graphPanel.add(panel);
		panel.setLayout(null);

		createLabels();
		createButtons();
		createInnerPanel();
		createComboboxes();
		able(false);

	}

	/**
	 * Used to enable/disable most of the buttons and comboboxes. All buttons are
	 * disabled until correct file is read.
	 * 
	 * @param b
	 */
	private void able(boolean b) {
		btnAddLine.setEnabled(b);
		btnAddWeight.setEnabled(b);
		btnShortestPath.setEnabled(b);
		btnZoomIn.setEnabled(b);
		btnZoomOut.setEnabled(b);
		nodeOne.setEnabled(b);
		nodeTwo.setEnabled(b);
		// nodeLines.setEnabled(b);
		edgeOne.setEnabled(b);
		btnLeastCostPath.setEnabled(b);
		btnLeastCostPathAll.setEnabled(b);
		btnSampleEdges.setEnabled(b);
		// clearBtn.setEnabled(b);

	}

	/**
	 * Used to create comboboxes.
	 */
	private void createComboboxes() {

		nodeOne = new JComboBox<String>();
		nodeOne.setBounds(6, 7, 162, 26);
		nodeOne.setSelectedItem(null);
		nodeOne.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				mainGraph.markNode(ui, 1, nodeOne.getSelectedIndex());
			}
		});
		graphPanel.add(nodeOne);

		nodeTwo = new JComboBox<String>();
		nodeTwo.setBounds(6, 45, 162, 26);
		nodeTwo.setSelectedItem(null);
		nodeTwo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				mainGraph.markNode(ui, 2, nodeTwo.getSelectedIndex());
			}
		});
		graphPanel.add(nodeTwo);

	}

	/**
	 * This method is used to create buttons.
	 */
	private void createButtons() {
		btnAddLine = new JButton("Add Line");
		btnAddLine.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int first = nodeOne.getSelectedIndex();
				int second = nodeTwo.getSelectedIndex();
				double weight;
				try {
					weight = Double.parseDouble(weightTxtFld.getText());
				} catch (NumberFormatException nfe) {
					weight = 0;
				}
				mainGraph.addEdge(mainGraph.getNodeList().get(first), mainGraph.getNodeList().get(second), weight);

				edgeOne.addItem(mainGraph.getNodeList().get(first).getName() + ">"
						+ mainGraph.getNodeList().get(second).getName());

				ui.drawGraph(mainGraph, STANDARD_GRAPH_COLOR, true);
			}
		});
		btnAddLine.setBounds(6, 133, 117, 29);
		graphPanel.add(btnAddLine);

		btnShortestPath = new JButton("Shortest Path");
		btnShortestPath.setBounds(920, 20, 117, 29);
		frame.getContentPane().add(btnShortestPath);
		btnShortestPath.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Öppna ny JFrame för att tillåta användaren att bestämma startpunkt och
				// slutpunkt

				WeightedGraph shortestPathGraph = mainGraph.getShortestDistance(
						Integer.parseInt(nodeOne.getSelectedItem().toString()),
						Integer.parseInt(nodeTwo.getSelectedItem().toString()));
				shortestPathGraph.drawGraph(ui, SHORTEST_DISTANCE_COLOR, false);
				currentGraph = shortestPathGraph;
			}
		});

		btnLeastCostPath = new JButton("Least Cost Path");
		btnLeastCostPath.setBounds(784, 100, 140, 29);
		frame.getContentPane().add(btnLeastCostPath);
		btnLeastCostPath.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Öppna ny JFrame för att tillåta användaren att bestämma startpunkt och
				// slutpunkt

				WeightedGraph leastCostGraph = mainGraph.getLeastCostPath(
						Integer.parseInt(nodeOne.getSelectedItem().toString()),
						Integer.parseInt(nodeTwo.getSelectedItem().toString()));
				leastCostGraph.drawGraph(ui, LEAST_COST_COLOR, false);
				currentGraph = leastCostGraph;
			}
		});

		btnLeastCostPathAll = new JButton("Least Cost Path (All possible)");
		btnLeastCostPathAll.setBounds(784, 140, 200, 29);
		frame.getContentPane().add(btnLeastCostPathAll);
		btnLeastCostPathAll.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Öppna ny JFrame för att tillåta användaren att bestämma startpunkt och
				// slutpunkt

				WeightedGraph leastCostGraph = mainGraph
						.getLeastCostPathAll(Integer.parseInt(nodeOne.getSelectedItem().toString()));
				leastCostGraph.drawGraph(ui, LEAST_COSTALL_COLOR, false);
				currentGraph = leastCostGraph;
			}
		});

		btnSampleEdges = new JButton("Sample Edges");
		btnSampleEdges.setBounds(784, 60, 117, 29);
		frame.getContentPane().add(btnSampleEdges);
		btnSampleEdges.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				ArrayList<Node> mainGraphNodes = mainGraph.getNodeList();
				mainGraph.addEdge(mainGraphNodes.get(0), mainGraphNodes.get(1), 5);
				edgeOne.addItem(mainGraphNodes.get(0).getName() + ">" + mainGraphNodes.get(1).getName());
				mainGraph.addEdge(mainGraphNodes.get(0), mainGraphNodes.get(2), 8);
				edgeOne.addItem(mainGraphNodes.get(0).getName() + ">" + mainGraphNodes.get(2).getName());
				mainGraph.addEdge(mainGraphNodes.get(0), mainGraphNodes.get(6), 18);
				edgeOne.addItem(mainGraphNodes.get(0).getName() + ">" + mainGraphNodes.get(6).getName());
				mainGraph.addEdge(mainGraphNodes.get(1), mainGraphNodes.get(2), 5);
				edgeOne.addItem(mainGraphNodes.get(1).getName() + ">" + mainGraphNodes.get(2).getName());
				mainGraph.addEdge(mainGraphNodes.get(1), mainGraphNodes.get(3), 7);
				edgeOne.addItem(mainGraphNodes.get(1).getName() + ">" + mainGraphNodes.get(3).getName());
				mainGraph.addEdge(mainGraphNodes.get(1), mainGraphNodes.get(7), 20);
				edgeOne.addItem(mainGraphNodes.get(1).getName() + ">" + mainGraphNodes.get(7).getName());
				mainGraph.addEdge(mainGraphNodes.get(2), mainGraphNodes.get(3), 3);
				edgeOne.addItem(mainGraphNodes.get(2).getName() + ">" + mainGraphNodes.get(3).getName());
				mainGraph.addEdge(mainGraphNodes.get(2), mainGraphNodes.get(4), 7);
				edgeOne.addItem(mainGraphNodes.get(2).getName() + ">" + mainGraphNodes.get(4).getName());
				mainGraph.addEdge(mainGraphNodes.get(3), mainGraphNodes.get(4), 5);
				edgeOne.addItem(mainGraphNodes.get(3).getName() + ">" + mainGraphNodes.get(4).getName());
				mainGraph.addEdge(mainGraphNodes.get(4), mainGraphNodes.get(5), 5);
				edgeOne.addItem(mainGraphNodes.get(4).getName() + ">" + mainGraphNodes.get(5).getName());
				mainGraph.addEdge(mainGraphNodes.get(4), mainGraphNodes.get(6), 10);
				edgeOne.addItem(mainGraphNodes.get(4).getName() + ">" + mainGraphNodes.get(6).getName());
				mainGraph.addEdge(mainGraphNodes.get(4), mainGraphNodes.get(7), 15);
				edgeOne.addItem(mainGraphNodes.get(4).getName() + ">" + mainGraphNodes.get(7).getName());
				mainGraph.addEdge(mainGraphNodes.get(5), mainGraphNodes.get(6), 4);
				edgeOne.addItem(mainGraphNodes.get(5).getName() + ">" + mainGraphNodes.get(6).getName());
				mainGraph.addEdge(mainGraphNodes.get(5), mainGraphNodes.get(7), 8);
				edgeOne.addItem(mainGraphNodes.get(5).getName() + ">" + mainGraphNodes.get(7).getName());
				mainGraph.addEdge(mainGraphNodes.get(5), mainGraphNodes.get(8), 12);
				edgeOne.addItem(mainGraphNodes.get(5).getName() + ">" + mainGraphNodes.get(8).getName());
				mainGraph.addEdge(mainGraphNodes.get(6), mainGraphNodes.get(8), 10);
				edgeOne.addItem(mainGraphNodes.get(6).getName() + ">" + mainGraphNodes.get(8).getName());
				mainGraph.addEdge(mainGraphNodes.get(7), mainGraphNodes.get(8), 8);
				edgeOne.addItem(mainGraphNodes.get(7).getName() + ">" + mainGraphNodes.get(8).getName());
				mainGraph.addEdge(mainGraphNodes.get(7), mainGraphNodes.get(9), 10);
				edgeOne.addItem(mainGraphNodes.get(7).getName() + ">" + mainGraphNodes.get(9).getName());
				mainGraph.addEdge(mainGraphNodes.get(8), mainGraphNodes.get(9), 3);
				edgeOne.addItem(mainGraphNodes.get(8).getName() + ">" + mainGraphNodes.get(9).getName());
				currentGraph = mainGraph;

				currentGraph.drawGraph(ui, STANDARD_GRAPH_COLOR, true);
			}
		});

		btnClearInfobox = new JButton("Clear infobox"); // Clear infobox btn
		btnClearInfobox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				infoBox.setText("");
			}
		});
		btnClearInfobox.setBounds(920, 526, 117, 29);
		frame.getContentPane().add(btnClearInfobox);

		btnZoomIn = new JButton("Zoom In"); // Zooma in knappen
		btnZoomIn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ui.zoom(ZOOM_VALUE);
			}
		});
		btnZoomIn.setBounds(370, 407, 117, 29);
		graphPanel.add(btnZoomIn);

		btnZoomOut = new JButton("Zoom Out"); // Zooma ut knappen
		btnZoomOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ui.zoom(-ZOOM_VALUE);
			}
		});
		btnZoomOut.setBounds(537, 407, 117, 29);
		graphPanel.add(btnZoomOut);

		readDataBtn = new JButton("Read data");
		readDataBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// testAgain();
				DataDAO file = null;
				try {
					file = new DataDAO();
					able(true);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				mainGraph = file.getGraph();

				for (int i = 0; i < mainGraph.getNodeList().size(); i++) {
					nodeOne.addItem(mainGraph.getNodeList().get(i).getName());
					nodeTwo.addItem(mainGraph.getNodeList().get(i).getName());
				}

				mainGraph.drawGraph(ui, STANDARD_GRAPH_COLOR, true);

				// ui.edgeOne();
			}

		});
		readDataBtn.setBounds(784, 20, 117, 29);
		frame.getContentPane().add(readDataBtn);

	}

	/**
	 * This method is used to create the inner panel.
	 */
	private void createInnerPanel() {
		weightTxtFld = new JTextField(); // Textfield for weight
		weightTxtFld.setBounds(6, 73, 130, 26);
		panel.add(weightTxtFld);
		weightTxtFld.setColumns(10);

		btnAddWeight = new JButton("Add Weight"); // Button for weight
		btnAddWeight.setBounds(154, 73, 117, 29);
		panel.add(btnAddWeight);

		edgeOne = new JComboBox<>(); // Options for the thing
		edgeOne.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Markera linjen
				// try{
				String[] lines = edgeOne.getSelectedItem().toString().split(">");
				mainGraph.markLine(ui, lines[0], lines[1]);
				// }catch(NullPointerException npe) {
				// System.out.println("Chilla äbri");
				// }

			}
		});
		edgeOne.setBounds(6, 35, 276, 26);
		panel.add(edgeOne);

		btnAddWeight.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Läs in vikten och skicka det till Calculations
				try {
					double weight = Double.parseDouble(weightTxtFld.getText());
					String[] lines = edgeOne.getSelectedItem().toString().split(">");

					Node startNode = null;
					Node endNode = null;

					for (int i = 0; i < mainGraph.getNodeList().size(); i++) {
						if (lines[0] == mainGraph.getNodeList().get(i).getName()) {
							startNode = mainGraph.getNodeList().get(i);
						}
						if (lines[1] == mainGraph.getNodeList().get(i).getName()) {
							endNode = mainGraph.getNodeList().get(i);
						}
					}

					mainGraph.setWeightToEdge(startNode, endNode, weight);

				} catch (NumberFormatException nfe) {
					infoBox.setText("Only numbers!");
				}
			}
		});

	}

	/**
	 * This method is used to create all labels.
	 */
	private void createLabels() {
		JLabel lblValdNod = new JLabel("Choosen node 1");
		lblValdNod.setBounds(180, 11, 85, 16);
		graphPanel.add(lblValdNod);

		JLabel lblValdNod_1 = new JLabel("Choosen node 2");
		lblValdNod_1.setBounds(180, 49, 72, 16);
		graphPanel.add(lblValdNod_1);

		JLabel lblValdLinje = new JLabel("Choosen edge");
		lblValdLinje.setBounds(294, 39, 70, 16);
		panel.add(lblValdLinje);

		infoBox = new JTextField();
		infoBox.setBounds(778, 320, 259, 202);
		infoBox.setEditable(false);
		frame.getContentPane().add(infoBox);
		infoBox.setColumns(10);
	}

}
