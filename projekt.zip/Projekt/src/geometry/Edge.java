package geometry;

import se.hig.aod_git.algorithms.geomalg.GeomAlgs2D;
/**
 * 
 * @author omar totangy and Elias Rönnlund
 * <b>Main Class for Edge</b>
 * This class is used to describe edges between point. 
 *
 */
public class Edge {
	
	Node startNode;
	Node endNode;
	double weight;
	double distance;
	GeomAlgs2D geom;
	/**
	 * Takes in a start node, end node and a weight for the edge. 
	 * @param startNode Node
	 * @param endNode Node
	 * @param weight double
	 */
	public Edge (Node startNode, Node endNode, double weight) {
		this.startNode = startNode;
		this.endNode = endNode;
		this.weight = weight;
		
		startNode.addStartEdge(this);
		endNode.addEndEdge(this);
		
	}
	/**
	 * This method is used to set weights to edges. 
	 * @param weight double
	 */
	public void setWeight (double weight) {
		this.weight = weight;
	}
	/**
	 * This method gets the start node of the edge.
	 * @return Node
	 */
	public Node getStartNode() {
		return startNode;
	}
	/**
	 * This method gets the end node of the edge. 
	 * @return Node
	 */
	public Node getEndNode() {
		return endNode;
	}
	/**
	 * This method gets the weight of the edge. 
	 * @return double
	 */
	public double getWeight() {
		return weight;
	}
	/**
	 * This method gets the distance of the edge. 
	 * @return double
	 */
	public double getDistance() {
		return Math.sqrt(Math.pow((endNode.getX() - startNode.getX()), 2) + Math.pow((endNode.getY() - startNode.getY()), 2));
	}
	
	

}
