package geometry;

import java.awt.Color;
import java.util.ArrayList;

import calculations.Calculations;
import graphGUI.GUI;
/**
 * 
 * @author Omar Totangy and Elias Rönnlund
 * <h1>WeightedGraph class</h1>
 * This class describes the WeightedGraph.
 *
 */
public class WeightedGraph {
	
	Calculations graphCalc = new Calculations();

	private ArrayList<Node> nodeList = new ArrayList<>();
	private ArrayList<Edge> edgeList = new ArrayList<>();
	
	public WeightedGraph() {
		
	}
	/**
	 * To add a node you need the node, and a string for the name of the node. 
	 * @param whichNode Node 
	 * @param whichOneForReading String 
	 */
	public void addNode(Node whichNode, String whichOneForReading) {
		whichNode.setName(whichOneForReading);
		nodeList.add(whichNode);
	}
	/**
	 * To add an edge you need startnode, endnode and weight for the edge. 
	 * @param startNode Node 
	 * @param endNode Node 
	 * @param weight double 
	 */
	public void addEdge(Node startNode, Node endNode, double weight) {
		edgeList.add(new Edge(startNode, endNode, weight));
	}
	/**
	 * Draws the graph so that the user can see. 
	 * @param gui GUI 
	 * @param color Color 
	 * @param remove boolean 
	 */
	public void drawGraph(GUI gui, Color color, boolean remove) {
		
		gui.drawGraph(this, color, remove);
		
	}
	/**
	 * Sets weight to edge.
	 * @param startNode Node 
	 * @param endNode Node 
	 * @param weight double 
	 */
	public void setWeightToEdge(Node startNode, Node endNode, double weight) {
		
		for (int i = 0; i < edgeList.size(); i++) {
			if (startNode == edgeList.get(i).getStartNode()) {
				if (endNode == edgeList.get(i).getEndNode()) {
					edgeList.get(i).setWeight(weight);
				}
			}
		}
	}
	/**
	 * Marks the selected node. 
	 * @param gui GUI
	 * @param nodeNbr int
	 * @param index int
	 */
	public void markNode(GUI gui, int nodeNbr, int index) {
		gui.markPoint(nodeNbr, nodeList.get(index));
	}
	/**
	 * Marks the selected edge.
	 * @param gui GUI
	 * @param start String
	 * @param end String
	 */
	public void markLine (GUI gui, String start, String end) {
		Node startNode = null;
		Node endNode = null;
		for (int i = 0; i < nodeList.size(); i++) {
			
			if (start.equals(nodeList.get(i).getName())) {
				startNode = nodeList.get(i);
			}
			if (end.equals(nodeList.get(i).getName())) {
				endNode = nodeList.get(i);
			}
		}
		gui.markLine(startNode, endNode);
	}
	/**
	 * Gets all least cost path for all possible. 
	 * @param startIndex int 
	 * @return WeightedGraph
	 */
	public WeightedGraph getLeastCostPathAll(int startIndex) {
		return graphCalc.leastCostPathAll(this, startIndex);
	}
	/**
	 * Gets the selected least cost path.
	 * @param startIndex int 
	 * @param endIndex int 
	 * @return WeightedGraph
	 */
	public WeightedGraph getLeastCostPath (int startIndex, int endIndex) {
		return graphCalc.leastCostPath(this, startIndex, endIndex);
	}
	/**
	 * Gets the shortest distance
	 * @param startIndex int 
	 * @param endIndex int 
	 * @return WeightedGraph
	 */
	public WeightedGraph getShortestDistance (int startIndex, int endIndex) {
		return graphCalc.shortestDistance(this, startIndex, endIndex);
	}
	/**
	 * Gets the list of nodes. 
	 * @return nodeList
	 */
	public ArrayList<Node> getNodeList(){
		return nodeList;
	}
	/**
	 * Gets the list of edges
	 * @return edgeList 
	 */
	public ArrayList<Edge> getEdgeList(){
		return edgeList;
	}
}
