package geometry;

import java.util.ArrayList;
/**
 * 
 * @author Omar Totangy and Elias Rönnlund
 *<b>Node Class</b>
 * This class is used to describe the type Node.
 * 
 */
public class Node{	
	
	private double x,y;
	private double weight, cumulativeWeight;
	private String name;
	private Node previousNode;
	private ArrayList<Edge> startEdges;
	private ArrayList<Edge> endEdges;
	
	public Node() {
		startEdges = new ArrayList<Edge>();
		endEdges = new ArrayList<Edge>();
	}	
	/**
	 * Sets the X value of the Node.
	 * @param X double 
	 */
	public void setX(double X) {
		x = X;
	}
	/**
	 * Sets the Y value of the node.
	 * @param Y double 
	 */
	public void setY(double Y) {
		y = Y;
	}
	/**
	 * Sets the name of the node. 
	 * @param s String 
	 */
	public void setName(String s) {
		name = s;
	}
	/**
	 * Sets weight of the node
	 * @param w double 
	 */
	public void setWeight(double w) {
		weight = w;
	}
	/**
	 * Sets the cumulative weight
	 * @param cw double 
	 */
	public void setCumulativeWeight(double cw) {
		cumulativeWeight = cw;
	}
	/**
	 * Sets the previous node.
	 * @param n Node 
	 */
	public void setPreviousNode(Node n) {
		previousNode = n;
	}
	/**
	 * Adds a starting edge for the node. 
	 * @param edge Edge 
	 */
	public void addStartEdge(Edge edge) {
		startEdges.add(edge);
	}
	/**
	 * Adds an end to the edge started. 
	 * @param edge Edge
	 */
	public void addEndEdge(Edge edge) {
		endEdges.add(edge);
	}
	/**
	 * Gets the X value of the node. 
	 * @return double
	 */
	public double getX() {
		return x;
	}
	/**
	 * Gets the Y value of the node. 
	 * @return double
	 */
	public double getY() {
		return y;
	}
	/**
	 * Gets the name of the node. 
	 * @return String
	 */
	public String getName() {
		return name;
	}
	/**
	 * Gets the weight of the node. 
	 * @return double
	 */
	public double getWeight() {
		return weight;
	}
	/**
	 * Gets the cumulative weight
	 * @return double
	 */
	public double getCumulativeWeight() {
		return cumulativeWeight;
	}
	/**
	 * Gets the previous node
	 * @return Node n
	 */
	public Node getPreviousNode() {
		return previousNode;
	}
	/**
	 * Gets all the starting edges to the node. 
	 * @return startEdges
	 */
	public ArrayList<Edge> getStartEdges(){
		return startEdges;
	}
	/**
	 * Gets all the ending edges to the node. 
	 * @return endEdges
	 */
	public ArrayList<Edge> getEndEdges(){
		return endEdges;
	}
	
	
	
	

}
