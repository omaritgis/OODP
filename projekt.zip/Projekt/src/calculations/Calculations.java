package calculations;

import java.util.ArrayList;

import geometry.Edge;
import geometry.Node;
import geometry.WeightedGraph;

/**
 * 
 * @author Omar Totangy and Elias Rönnlund
 *         <h1>Calculations Class</h1> This class is used for calculations such
 *         as least cost path.
 */
public class Calculations {
	/**
	 * Calculates all possible least cost.
	 * 
	 * @param graph      WeightedGraph
	 * @param startIndex int
	 * @return WeightedGraph
	 */
	public WeightedGraph leastCostPathAll(WeightedGraph graph, int startIndex) {

		WeightedGraph minSusTree = new WeightedGraph();
		ArrayList<Node> nodeList = new ArrayList<Node>();

		// Lägger in alla noder från graph till nya grafen minSusTree
		for (Node n : graph.getNodeList()) {
			minSusTree.addNode(n, n.toString());
		}

		// Lägger in första noden från grafen i nodlistan
		Node node = graph.getNodeList().get(0);
		node.setCumulativeWeight(0);
		node.setWeight(0);
		node.setPreviousNode(null);
		nodeList.add(node);

		// Lägger in alla andra noder från grafen i nodlistan. Sätter CWeight till
		// infinit istället för 0.
		for (Node n : graph.getNodeList()) {
			if (n != node) {
				n.setCumulativeWeight(Double.POSITIVE_INFINITY);
				n.setWeight(0);
				node.setPreviousNode(null);
				nodeList.add(n);
			}
		}

		while (nodeList.size() != 0) {
			Node currentNode = nodeList.get(0);
			int index = -1;
			int lowestNodeIndex = 0;

			// Tar bort noden med minsta cCost från nodeList
			for (Node n : nodeList) {
				index++;
				if (n.getCumulativeWeight() < currentNode.getCumulativeWeight()) {
					currentNode = n;
					lowestNodeIndex = index;
				}
			}
			nodeList.remove(lowestNodeIndex);

			// Fortsätter bygga vägen i grafen
			if (currentNode.getPreviousNode() != null) {
				Node newNode = new Node();
				newNode.setX(currentNode.getX());
				newNode.setY(currentNode.getY());
				newNode.setName(currentNode.getName());
				minSusTree.addEdge(currentNode.getPreviousNode(), newNode, currentNode.getWeight());
			}

			// Etablerar nästa nod
			Node adjacent;
			for (Edge e : currentNode.getStartEdges()) {
				adjacent = e.getEndNode();
				if (adjacent.getCumulativeWeight() > currentNode.getCumulativeWeight() + e.getWeight()) {
					adjacent.setCumulativeWeight(currentNode.getCumulativeWeight() + e.getWeight());
					adjacent.setWeight(e.getWeight());
					Node newNode = new Node();
					newNode.setX(currentNode.getX());
					newNode.setY(currentNode.getY());
					newNode.setName(currentNode.getName());
					newNode.setPreviousNode(currentNode.getPreviousNode());
					adjacent.setPreviousNode(newNode);
				}
			}
		}
		return minSusTree;
	}

	/**
	 * Calculates selected least cost path.
	 * 
	 * @param graph      WeightedGraph
	 * @param startIndex int
	 * @param endIndex   int
	 * @return WeightedGraph
	 */
	public WeightedGraph leastCostPath(WeightedGraph graph, int startIndex, int endIndex) {

		WeightedGraph minSusTree = new WeightedGraph();
		ArrayList<Node> nodeList = new ArrayList<Node>();

		// byter plats på variablerna
		if (startIndex > endIndex) {
			int tempIndex = startIndex;
			startIndex = endIndex;
			endIndex = tempIndex;
		}

		// Lägger in alla noder från graph till nya grafen minSusTree
		for (Node n : graph.getNodeList()) {
			minSusTree.addNode(n, n.toString());
		}

		// Lägger in första noden från grafen i nodlistan
		Node node = graph.getNodeList().get(startIndex);
		node.setCumulativeWeight(0);
		node.setWeight(0);
		node.setPreviousNode(null);
		nodeList.add(node);

		// Lägger in alla andra noder från grafen i nodlistan. Sätter CWeight till
		// infinit istället för 0.
		for (Node n : graph.getNodeList()) {
			if (n != node) {
				n.setCumulativeWeight(Double.POSITIVE_INFINITY);
				n.setWeight(0);
				n.setPreviousNode(null);
				nodeList.add(n);
			}
		}

		while (nodeList.size() != 0) {
			Node currentNode = nodeList.get(0);
			int index = -1;
			int lowestNodeIndex = 0;

			// Tar bort noden med minsta cCost från nodeList
			for (Node n : nodeList) {
				index++;
				if (n.getCumulativeWeight() < currentNode.getCumulativeWeight()) {
					currentNode = n;
					lowestNodeIndex = index;
				}
			}
			nodeList.remove(lowestNodeIndex);

			// Fortsätter bygga vägen i grafen
			if (currentNode.getPreviousNode() != null) {
				Node newNode = new Node();
				newNode.setX(currentNode.getX());
				newNode.setY(currentNode.getY());
				newNode.setName(currentNode.getName());
				minSusTree.addEdge(currentNode.getPreviousNode(), newNode, currentNode.getWeight());
			}

			// Stannar vid slutnoden och bygger ihop graf med least cost path till den
			if (graph.getNodeList().get(endIndex) == currentNode) {
				minSusTree = new WeightedGraph();
				Node newNode = new Node();
				newNode.setX(currentNode.getX());
				newNode.setY(currentNode.getY());
				newNode.setName(currentNode.getName());
				newNode.setPreviousNode(currentNode.getPreviousNode());
				Node tempNode = newNode;
				while (tempNode.getPreviousNode() != null) {
					minSusTree.addNode(tempNode, "");
					minSusTree.addEdge(tempNode.getPreviousNode(), tempNode, 0);
					tempNode = tempNode.getPreviousNode();
				}
				minSusTree.addNode(tempNode, "");
				return minSusTree;
			}

			// Etablerar nästa nod
			Node adjacent;
			for (Edge e : currentNode.getStartEdges()) {
				adjacent = e.getEndNode();
				if (adjacent.getCumulativeWeight() > currentNode.getCumulativeWeight() + e.getWeight()) {
					adjacent.setCumulativeWeight(currentNode.getCumulativeWeight() + e.getWeight());
					adjacent.setWeight(e.getWeight());
					Node newNode = new Node();
					newNode.setX(currentNode.getX());
					newNode.setY(currentNode.getY());
					newNode.setName(currentNode.getName());
					newNode.setPreviousNode(currentNode.getPreviousNode());
					adjacent.setPreviousNode(newNode);
				}
			}
		}
		return minSusTree;
	}

	/**
	 * Calculates shortest distance.
	 * 
	 * @param graph      WeightedGraph
	 * @param startIndex int
	 * @param endIndex   int
	 * @return WeightedGraph
	 */
	public WeightedGraph shortestDistance(WeightedGraph graph, int startIndex, int endIndex) {

		WeightedGraph minSusTree = new WeightedGraph();
		ArrayList<Node> nodeList = new ArrayList<Node>();

		// byter plats på variablerna
		if (startIndex > endIndex) {
			int tempIndex = startIndex;
			startIndex = endIndex;
			endIndex = tempIndex;
		}

		// Lägger in alla noder från graph till nya grafen minSusTree
		for (Node n : graph.getNodeList()) {
			minSusTree.addNode(n, n.toString());
		}

		// Lägger in första noden från grafen i nodlistan
		Node node = graph.getNodeList().get(startIndex);
		node.setCumulativeWeight(0);
		node.setWeight(0);
		node.setPreviousNode(null);
		nodeList.add(node);
		// Lägger in alla andra noder från grafen i nodlistan. Sätter CWeight till
		// infinit istället för 0.
		for (Node n : graph.getNodeList()) {
			if (n != node) {
				n.setCumulativeWeight(Double.POSITIVE_INFINITY);
				n.setWeight(0);
				n.setPreviousNode(null);
				nodeList.add(n);
			}
		}

		while (nodeList.size() != 0) {
			Node currentNode = nodeList.get(0);
			int index = -1;
			int lowestNodeIndex = 0;
			// Tar bort noden med minsta cCost från nodeList
			for (Node n : nodeList) {
				index++;
				if (n.getCumulativeWeight() < currentNode.getCumulativeWeight()) {
					currentNode = n;
					lowestNodeIndex = index;
				}
			}
			nodeList.remove(lowestNodeIndex);
			// Fortsätter bygga vägen i grafen
			if (currentNode.getPreviousNode() != null) {
				Node newNode = new Node();
				newNode.setX(currentNode.getX());
				newNode.setY(currentNode.getY());
				newNode.setName(currentNode.getName());
				minSusTree.addEdge(currentNode.getPreviousNode(), newNode, currentNode.getWeight());
			}
			// Stannar vid slutnoden och bygger ihop graf med least cost path till den
			if (graph.getNodeList().get(endIndex) == currentNode) {
				minSusTree = new WeightedGraph();
				Node newNode = new Node();
				newNode.setX(currentNode.getX());
				newNode.setY(currentNode.getY());
				newNode.setName(currentNode.getName());
				newNode.setPreviousNode(currentNode.getPreviousNode());
				Node tempNode = newNode;
				while (tempNode.getPreviousNode() != null) {
					minSusTree.addNode(tempNode, "");
					minSusTree.addEdge(tempNode.getPreviousNode(), tempNode, 0);
					tempNode = tempNode.getPreviousNode();
				}
				minSusTree.addNode(tempNode, "");
				return minSusTree;
			}
			// Etablerar nästa nod
			Node adjacent;
			for (Edge e : currentNode.getStartEdges()) {
				adjacent = e.getEndNode();
				if (adjacent.getCumulativeWeight() > currentNode.getCumulativeWeight() + e.getDistance()) {
					adjacent.setCumulativeWeight(currentNode.getCumulativeWeight() + e.getDistance());
					adjacent.setWeight(e.getDistance());
					Node newNode = new Node();
					newNode.setX(currentNode.getX());
					newNode.setY(currentNode.getY());
					newNode.setName(currentNode.getName());
					newNode.setPreviousNode(currentNode.getPreviousNode());
					adjacent.setPreviousNode(newNode);
				}
			}
		}
		return minSusTree;
	}
}
